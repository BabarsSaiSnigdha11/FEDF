export async function fetchBooks() {
  const res = await fetch('./data/books.json', {cache: "no-store"});
  if (!res.ok) throw new Error('Failed to fetch books');
  return res.json();
}
