const STORAGE_KEY = 'modular_bookstore_cart_v1';

export function loadCart() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch(e) {
    console.error('Failed to load cart', e);
    return {};
  }
}

export function saveCart(cart) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cart));
}

export function addToCart(cart, book) {
  const existing = cart[book.id] || {...book, qty:0};
  existing.qty = (existing.qty || 0) + 1;
  cart[book.id] = existing;
  saveCart(cart);
  return cart;
}

export function removeFromCart(cart, bookId) {
  delete cart[bookId];
  saveCart(cart);
  return cart;
}

export function clearCart() {
  localStorage.removeItem(STORAGE_KEY);
  return {};
}

export function cartSummary(cart) {
  const items = Object.values(cart);
  const count = items.reduce((s,i)=>s+(i.qty||0),0);
  const total = items.reduce((s,i)=>s+(i.qty||0)*(i.price||0),0);
  return {count,total};
}
