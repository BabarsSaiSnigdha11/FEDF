Modular JS Online Bookstore (Demo)
=================================

What you get:
- A small modular JavaScript project using ES modules (api.js, cart.js, main.js).
- A local JSON file with sample books (data/books.json).
- Simple UI to add books to cart, view cart, remove items, clear cart, and checkout (demo alert).
- Cart persisted in localStorage.

How to run:
1. This project uses fetch() to load data from /data/books.json. To run locally, start a simple static server:
   - Python 3: `python -m http.server 8000` (from the project root)
   - Then open `http://localhost:8000` in your browser.

2. The app uses ES modules, so it needs to be served over HTTP (file:// won't work for module fetches).

Files:
- index.html
- css/styles.css
- js/main.js
- js/api.js
- js/cart.js
- data/books.json

License: MIT
