export async function fetchBooks() {
  // In a real app you'd fetch('/data/books.json') — here we load the JSON file
  const res = await fetch('/data/books.json', {cache: "no-store"});
  if (!res.ok) throw new Error('Failed to fetch books');
  return res.json();
}
