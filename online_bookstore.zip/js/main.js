import { fetchBooks } from './api.js';
import * as Cart from './cart.js';

const booksEl = document.getElementById('books');
const template = document.getElementById('book-template');
const cartCountEl = document.getElementById('cart-count');
const cartTotalEl = document.getElementById('cart-total');
const cartTotalBottomEl = document.getElementById('cart-total-bottom');
const cartItemsEl = document.getElementById('cart-items');
const checkoutBtn = document.getElementById('checkout');
const clearBtn = document.getElementById('clear-cart');

let cart = Cart.loadCart();

function formatINR(n){ return n.toFixed(2); }

function renderCart() {
  const summary = Cart.cartSummary(cart);
  cartCountEl.textContent = summary.count;
  cartTotalEl.textContent = formatINR(summary.total);
  cartTotalBottomEl.textContent = formatINR(summary.total);

  cartItemsEl.innerHTML = '';
  Object.values(cart).forEach(item=>{
    const li = document.createElement('li');
    li.innerHTML = `<span>${item.title} × ${item.qty}</span><span>₹${formatINR(item.price * item.qty)}</span>`;
    const removeBtn = document.createElement('button');
    removeBtn.textContent = 'Remove';
    removeBtn.style.marginLeft = '8px';
    removeBtn.onclick = () => {
      Cart.removeFromCart(cart, item.id);
      cart = Cart.loadCart();
      renderCart();
    };
    li.appendChild(removeBtn);
    cartItemsEl.appendChild(li);
  });
}

function renderBooks(books) {
  booksEl.innerHTML = '';
  books.forEach(book=>{
    const node = template.content.cloneNode(true);
    node.querySelector('.cover').src = book.cover;
    node.querySelector('.title').textContent = book.title;
    node.querySelector('.author').textContent = book.author;
    node.querySelector('.price').textContent = `₹${formatINR(book.price)}`;
    const btn = node.querySelector('.add-btn');
    btn.onclick = () => {
      Cart.addToCart(cart, book);
      cart = Cart.loadCart();
      renderCart();
    };
    booksEl.appendChild(node);
  });
}

async function init() {
  try {
    const books = await fetchBooks();
    renderBooks(books);
    renderCart();
  } catch(e) {
    booksEl.innerHTML = '<p>Failed to load books.</p>';
    console.error(e);
  }
}

checkoutBtn.onclick = () => {
  const summary = Cart.cartSummary(cart);
  if(summary.count === 0) {
    alert('Your cart is empty.');
    return;
  }
  alert(`Checkout — ${summary.count} items. Total: ₹${formatINR(summary.total)}\n(This is a demo.)`);
  cart = Cart.clearCart();
  renderCart();
};

clearBtn.onclick = () => {
  if(!confirm('Clear the cart?')) return;
  cart = Cart.clearCart();
  renderCart();
};

init();
